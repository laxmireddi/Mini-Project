from django.forms import Form, IntegerField


class InputForm(Form):
    f1 = IntegerField()
    f2 = IntegerField()
    f3 = IntegerField()
    f4 = IntegerField()
    f5 = IntegerField()
    f6 = IntegerField()
    f7 = IntegerField()
    f8 = IntegerField()
    f9 = IntegerField()
    f10 = IntegerField()
    f11 = IntegerField()
    f12 = IntegerField()
    f13 = IntegerField()
    f14 = IntegerField()
    f15 = IntegerField()
    f16 = IntegerField()
