from django.shortcuts import render
from careerguidance.forms import InputForm
import pickle

def predict(request):

    if request.method == "POST":
        inputForm = InputForm(request.POST)

        if inputForm.is_valid():

            lmapping={' MSc Microbiology ': 0, 'Arts': 1, 'B. Sc genetics and biotechnology ': 2
                , 'Bsc.Foodscience': 3, 'Commerce': 4, 'Designing': 5, 'Diploma': 6, 'Engineering': 7
                , 'Humanities': 8, 'Management studies ': 9, 'Medical': 10, 'Science': 11, 'Science ': 12}

            rf_classifier = pickle.load(open('C:\\Users\\mahes\\OneDrive\\Desktop\\mini\\CareerGuidanceFor12thGrade\\model\\randomforest_model.pickle', 'rb'))

            f1 = inputForm.cleaned_data["f1"]
            f2 = inputForm.cleaned_data["f2"]
            f3 = inputForm.cleaned_data["f3"]
            f4 = inputForm.cleaned_data["f4"]
            f5 = inputForm.cleaned_data["f5"]
            f6 = inputForm.cleaned_data["f6"]
            f7 = inputForm.cleaned_data["f7"]
            f8 = inputForm.cleaned_data["f8"]
            f9 = inputForm.cleaned_data["f9"]
            f10 = inputForm.cleaned_data["f10"]
            f11 = inputForm.cleaned_data["f11"]
            f12 = inputForm.cleaned_data["f12"]
            f13 = inputForm.cleaned_data["f13"]
            f14 = inputForm.cleaned_data["f14"]
            f15 = inputForm.cleaned_data["f15"]
            f16 = inputForm.cleaned_data["f16"]

            prediction = rf_classifier.predict([[f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16]])
            result=list(lmapping.keys())[list(lmapping.values()).index(prediction[0])]
            print(result)

            return render(request, "index.html", {"result": result})

        else:
            return render(request, 'index.html', {"message": "Please Fill Form Data"})
    else:
        return render(request, 'index.html', {"message": "Invalid Request"})